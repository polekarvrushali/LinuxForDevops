#!/bin/bash


#echo "I will become a devops Engineer"


name="Vrushali"
echo " I am ${name}, please enter your city"

read city

echo "My city name is ${city}"

echo "$1"
