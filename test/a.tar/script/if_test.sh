#!/bin/bash

if [ "$1" = "like" ]
then
	echo "I $1 summer season"
else
	echo "Its a winter"
fi	

