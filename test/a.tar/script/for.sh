#!/bin/bash


for FILE in *.txt
do 
	echo $FILE
done
