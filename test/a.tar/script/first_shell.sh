#!/bin/bash

mkdir new_dir
cd new_dir
touch newfile.txt
echo "this is a text file" > newfile.txt
cat newfile.txt
